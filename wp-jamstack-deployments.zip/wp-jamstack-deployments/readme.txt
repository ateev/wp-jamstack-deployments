=== JAMstack Deployments ===
Contributors: crgeary
Tags: jamstack, netlify, webhook
Tested up to: 5.1
Requires PHP: 5.6
License: GPL-3.0
License URI: https://github.com/crgeary/wp-jamstack-deployments/blob/master/LICENSE

A WordPress plugin for JAMstack deployments on Netlify (and other platforms).

== Description ==
Please refer to the Github repository [crgeary/wp-jamstack-deployments](https://github.com/crgeary/wp-jamstack-deployments) for usage instructions, and for support.